//
//  GetPlayersInfoResponse.swift
//  DynamoIOSTestTask
//
//  Created by Yaroslav Shepilov on 02.06.2022.
//

import Foundation

struct GetPlayersInfoResponse: Codable {
    let data: [Player]
    let meta: Meta
}

struct Player: Codable {
    let id: Int
    let firstName: String
    let heightFeet: Int? // "height_feet": null in some case
    let heightInches: Int? // "height_inches": null in some case
    let lastName: String
    let position: String? // some players have property "position": ""
    let team: Team
    let weightPounds: Int? // "weight_pounds": null in some case

    enum CodingKeys: String, CodingKey {
        case id
        case firstName = "first_name"
        case heightFeet = "height_feet"
        case heightInches = "height_inches"
        case lastName = "last_name"
        case position
        case team
        case weightPounds = "weight_pounds"
    }
}

struct Meta: Codable {
    let totalPages: Int
    let currentPage: Int
    let nextPage: Int
    let perPage: Int
    let totalCount: Int

    enum CodingKeys: String, CodingKey {
        case totalPages = "total_pages"
        case currentPage = "current_page"
        case nextPage = "next_page"
        case perPage = "per_page"
        case totalCount = "total_count"
    }
}

struct Team: Codable {
    let id: Int
    let abbreviation: String
    let city: String
    let conference: String
    let division: String
    let fullName: String
    let name: String

    enum CodingKeys: String, CodingKey {
        case id
        case abbreviation
        case city
        case conference
        case division
        case fullName = "full_name"
        case name
    }
}

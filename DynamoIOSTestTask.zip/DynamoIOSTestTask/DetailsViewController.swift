//
//  DetailsViewController.swift
//  DynamoIOSTestTask
//
//  Created by Yaroslav Shepilov on 02.06.2022.
//

import UIKit

class DetailsViewController: UIViewController {
    
    @IBOutlet weak var firstNameLabel: UILabel!
    @IBOutlet weak var secondNameLabel: UILabel!
    @IBOutlet weak var heightLabel: UILabel!
    @IBOutlet weak var weightLabel: UILabel!
    @IBOutlet weak var positionLabel: UILabel!
    @IBOutlet weak var teamNameLabel: UILabel!
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var conferenceLabel: UILabel!
    @IBOutlet weak var divisionLabel: UILabel!

    var details: Player
    
    init(player: Player) {
        self.details = player
        super.init(nibName: "DetailsViewController", bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupDetailsScreen()
    }
    
    func setupDetailsScreen() {
        title = "Details"
        firstNameLabel.text = details.firstName
        secondNameLabel.text = details.lastName
        positionLabel.text = details.position // in API can be "", set default value "No info"
        if positionLabel.text == "" {
            positionLabel.text = "No info"
        }
        heightLabel.text = "\(details.heightInches ?? 0)" // in API can be null, set default value 0 for this case
        if heightLabel.text == "0" {
            heightLabel.text = "No info"
        }
        weightLabel.text = "\(details.weightPounds ?? 0)"  // in API can be null, set default value 0 for this case
        if weightLabel.text == "0" {
            weightLabel.text = "No info"
        }
        teamNameLabel.text = details.team.fullName
        cityLabel.text = details.team.city
        conferenceLabel.text = details.team.conference
        divisionLabel.text = details.team.division
    }
}

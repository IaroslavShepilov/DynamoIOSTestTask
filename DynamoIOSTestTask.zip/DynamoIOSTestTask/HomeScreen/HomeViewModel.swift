//
//  HomeViewModel.swift
//  DynamoIOSTestTask
//
//  Created by Yaroslav Shepilov on 03.06.2022.
//

import Foundation

protocol HomeViewModelProtocol {
    func updatePlayersInfo(response: [Player])
}

final class HomeViewModel {
    
    var delegate: HomeViewModelProtocol?
    var players = [Player]()
    var pageNumber = 1
    var fetchingMore = false
    var isProcesing = false

    func getPlayers() {
        isProcesing = true
        NetworkService.request(router: GetPlayersInfoRequest(pageNumber: pageNumber)) { [weak self] (result: Result<GetPlayersInfoResponse, Error>) in
            switch result {
            case .success(let response):
                DispatchQueue.main.async {
                    self?.players.append(contentsOf: response.data)
                    guard let players = self?.players else { return }
                    self?.delegate?.updatePlayersInfo(response: players)
                    self?.isProcesing = false
                } 
            case .failure(let error):
                print(error)
            }
        }
    }
  
    func increasePageNumber() {
        if !isProcesing {
            isProcesing = true
            pageNumber += 1
            getPlayers()
        }
    }
}

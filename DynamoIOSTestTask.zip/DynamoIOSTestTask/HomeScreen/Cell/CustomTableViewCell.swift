//
//  CustomTableViewCell.swift
//  DynamoIOSTestTask
//
//  Created by Yaroslav Shepilov on 02.06.2022.
//

import UIKit

class CustomTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}

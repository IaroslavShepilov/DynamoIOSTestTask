//
//  HomeViewController.swift
//  DynamoIOSTestTask
//
//  Created by Yaroslav Shepilov on 02.06.2022.
//

import UIKit

class HomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    let searchController = UISearchController(searchResultsController: nil)
    private var model = HomeViewModel()
    private var players = [Player]()
    private var filteredPlayers = [Player]()
    private var isFiltering = false
    var didAppear = false
    var isSearchBarEmpty: Bool {
        guard let text = searchController.searchBar.text else { return false }
        return text.isEmpty
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Players"
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.model.delegate = self
        tableView.register(UINib.init(nibName: "CustomTableViewCell", bundle: nil), forCellReuseIdentifier: "reuseIdentifier")
        model.getPlayers()
        setupSearchController()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        didAppear = true
    }
    
    func setupSearchController() {
        searchController.delegate = self
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "Search"
        navigationItem.searchController = searchController
        definesPresentationContext = true
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isFiltering {
            return filteredPlayers.count
        }
        return players.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: CustomTableViewCell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath) as! CustomTableViewCell
        let player: Player
        if isFiltering {
          player = filteredPlayers[indexPath.row]
        } else {
          player = players[indexPath.row]
        }
        cell.textLabel?.text = player.firstName + " " + player.lastName
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let player: Player
        if isFiltering {
          player = filteredPlayers[indexPath.row]
        } else {
          player = players[indexPath.row]
        }
        let addVC = DetailsViewController(player: player)
        navigationController?.pushViewController(addVC, animated: true)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let height = scrollView.frame.size.height
        let contentYoffset = scrollView.contentOffset.y
        let distanceFromBottom = scrollView.contentSize.height - contentYoffset
        if distanceFromBottom < height && didAppear && !model.isProcesing {
            model.increasePageNumber()
        }
    }
}

extension HomeViewController: HomeViewModelProtocol {
    func updatePlayersInfo(response: [Player]) {
        self.players = response
        tableView.reloadData()
    }
}

extension HomeViewController: UISearchResultsUpdating, UISearchControllerDelegate {
    
    func updateSearchResults(for searchController: UISearchController) {
        let searchBar = searchController.searchBar
        filterContentForSearchText(searchBar.text)
        tableView.reloadData()
    }
   
    func willPresentSearchController(_ searchController: UISearchController) {
        isFiltering = true
        tableView.reloadData()
    }

    func willDismissSearchController(_ searchController: UISearchController) {
        isFiltering = false
        tableView.reloadData()
    }
    
    private func filterContentForSearchText(_ searchText: String?) {
        filteredPlayers = players.filter {
            let fullName = $0.firstName.lowercased() + " " + $0.lastName.lowercased()
            return fullName.contains(searchText?.lowercased() ?? "")
        }
      tableView.reloadData()
    }
}


//
//  ViewController.swift
//  DynamoIOSTestTask
//
//  Created by Yaroslav Shepilov on 02.06.2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}


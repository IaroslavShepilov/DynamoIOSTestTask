//
//  NetworkConstants.swift
//  DynamoIOSTestTask
//
//  Created by Yaroslav Shepilov on 02.06.2022.
//

import Foundation

public struct NetworkConstants {
 
    public enum Method: String {
        case GET = "GET"
        case POST = "POST"
    }
    
    public enum Path: String {
        case players = "/api/v1/players"
    }

    public static let scheme = "https"
    public static let host = "www.balldontlie.io"
}

//
//  AboutViewController.swift
//  DynamoIOSTestTask
//
//  Created by Yaroslav Shepilov on 02.06.2022.
//

import UIKit

class AboutViewController: UIViewController {
    
    @IBOutlet weak var currentAppVersionLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "About"
        getTime()
    }
    
    func getTime () {
        let date = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "YYYYMMDD" // or "YYYY:MM:DD" to get current day of the year // or "YYYY:MM:dd" to get current day of the month but in task say use YYYYMMDD
        let yearMonthDayString = dateFormatter.string(from: date)
        currentAppVersionLabel.text = "\(UIApplication.versionBuild())" + "." + yearMonthDayString
    }
}

extension UIApplication {
    struct Constants {
        static let CFBundleShortVersionString = "CFBundleShortVersionString"
    }
    class func appVersion() -> String {
        return Bundle.main.object(forInfoDictionaryKey: Constants.CFBundleShortVersionString) as! String
    }

    class func appBuild() -> String {
        return Bundle.main.object(forInfoDictionaryKey: kCFBundleVersionKey as String) as! String
    }
    
    class func versionBuild() -> String {
        let version = appVersion(), build = appBuild()
        return version == build ? "\(version)" : "\(version)"
    }
}

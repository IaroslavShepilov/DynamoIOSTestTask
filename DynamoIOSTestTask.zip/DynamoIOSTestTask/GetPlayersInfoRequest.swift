//
//  GetPlayersInfoRequest.swift
//  DynamoIOSTestTask
//
//  Created by Yaroslav Shepilov on 02.06.2022.
//

import Foundation

struct GetPlayersInfoRequest: NetworkRequestProtocol {
    var scheme: String = NetworkConstants.scheme
    var host: String = NetworkConstants.host
    var path: String = NetworkConstants.Path.players.rawValue
    var parameters: [URLQueryItem] = [
        URLQueryItem(name: "perPage",value: "25")
    ]
    var method: NetworkConstants.Method = .GET
    var httpAdditionalHeader: [String : String] = [:]
    init(pageNumber: Int) {
        parameters.append(URLQueryItem(name: "page", value: "\(pageNumber)")) // "current_page" don't work, "page" its ok 
    }
}
